package com.example.demo.chapter15;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/register")
public class Chapter15Controller {
	

}
