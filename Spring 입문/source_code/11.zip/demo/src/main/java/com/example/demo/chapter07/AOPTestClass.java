package com.example.demo.chapter07;

import org.aspectj.lang.annotation.Aspect;

@Aspect
public class AOPTestClass {
	//AOP는 스킵
}
