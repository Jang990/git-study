package com.example.demo.chapter13.toyprj;

import org.springframework.stereotype.Controller;

@Controller
public class Chapter13ToyPrjController {
	
}
