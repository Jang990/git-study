package com.example.demo.chapter02;

public class MyPet extends Pet{
	@Override
	public String getName() {
		return "Dog";
	}
}
